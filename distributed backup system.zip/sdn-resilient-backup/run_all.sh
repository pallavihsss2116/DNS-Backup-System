#!/usr/bin/env bash
# Start everything for the demo.  Run as your normal user (it uses sudo only for Mininet):
#
#     ./run_all.sh /path/to/pox
#
# 1. copies the controller into pox/ext and starts POX (background, log in /tmp/sdnbackup/logs/pox.log)
# 2. starts the Tkinter dashboard (background, needs your desktop session)
# 3. starts Mininet in the foreground (Mininet CLI). Type `exit` there to stop everything.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
POX_DIR="${1:-$HOME/pox}"
[ -f "$POX_DIR/pox.py" ] || { echo "pox.py not found in $POX_DIR  (usage: $0 /path/to/pox)"; exit 1; }

mkdir -p /tmp/sdnbackup/logs
chmod -R 777 /tmp/sdnbackup 2>/dev/null || true
: > /tmp/sdnbackup/events.jsonl
chmod 666 /tmp/sdnbackup/events.jsonl

sudo mn -c >/dev/null 2>&1 || true            # clean leftovers from a previous run
cp "$HERE/controller/multipath_controller.py" "$POX_DIR/ext/multipath_controller.py"

( cd "$POX_DIR" && exec python3 pox.py log.level --INFO openflow.discovery openflow.spanning_tree multipath_controller \
    > /tmp/sdnbackup/logs/pox.log 2>&1 ) &
POX_PID=$!
python3 "$HERE/dashboard/app.py" > /tmp/sdnbackup/logs/dashboard.log 2>&1 &
DASH_PID=$!
trap 'kill $POX_PID $DASH_PID 2>/dev/null; sudo mn -c >/dev/null 2>&1' EXIT

sleep 3
sudo -E python3 "$HERE/topology/topology.py" --delay 0.02
