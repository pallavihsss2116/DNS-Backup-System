#!/usr/bin/env python3
"""Run the whole backup + failover scenario on one machine, no Mininet needed.

  python3 local_demo.py                 # 24 MB file, kill primary after 1.5 s
  python3 local_demo.py --size-mb 100 --kill-after 4

Open the dashboard first (python3 dashboard/app.py) to watch it live.
Steps: start primary + standby -> backup -> kill primary mid-transfer ->
verify the backup finished on the standby -> restore -> compare file hashes ->
restart primary and check it re-syncs the chunks it missed.
"""
import argparse
import hashlib
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
SERVER = os.path.join(ROOT, "backup", "server.py")
CLIENT = os.path.join(ROOT, "backup", "client.py")
BASE = "/tmp/sdnbackup/local"


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def start_server(name, port, peer_port, peer_name, delay, resync=True):
    args = [PY, SERVER, "--name", name, "--port", str(port), "--bind", "127.0.0.1",
            "--data", os.path.join(BASE, name), "--peer", "127.0.0.1:%d" % peer_port,
            "--peer-name", peer_name, "--delay", str(delay)]
    if not resync:
        args.append("--no-resync")
    return subprocess.Popen(args, stdout=subprocess.DEVNULL)


def count_chunks(name):
    n = 0
    d = os.path.join(BASE, name)
    for _, _, files in os.walk(d):
        n += sum(1 for f in files if f.endswith(".chunk"))
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--size-mb", type=float, default=24)
    ap.add_argument("--chunk-kb", type=int, default=256)
    ap.add_argument("--delay", type=float, default=0.08, help="seconds of fake latency per chunk")
    ap.add_argument("--kill-after", type=float, default=1.5)
    ap.add_argument("--keep", action="store_true", help="leave servers running at the end")
    a = ap.parse_args()

    os.system("rm -rf %s /tmp/sdnbackup/meta" % BASE)
    os.makedirs(BASE, exist_ok=True)
    src = os.path.join(BASE, "testfile.bin")
    with open(src, "wb") as f:
        f.write(os.urandom(int(a.size_mb * 1024 * 1024)))
    srv_spec = "h3=127.0.0.1:19003,h2=127.0.0.1:19002"

    h3 = start_server("h3", 19003, 19002, "h2", a.delay, resync=False)
    h2 = start_server("h2", 19002, 19003, "h3", a.delay, resync=False)
    time.sleep(0.8)

    print("== backup %.1f MB, will kill primary h3 after %.1fs" % (a.size_mb, a.kill_after))
    cl = subprocess.Popen([PY, CLIENT, "backup", src, "--servers", srv_spec,
                           "--chunk-size", str(a.chunk_kb * 1024), "--workers", "4"],
                          stdout=subprocess.PIPE, text=True)
    time.sleep(a.kill_after)
    h3.kill()
    h3.wait()
    print("== h3 killed")
    out, _ = cl.communicate(timeout=300)
    print(out.strip())
    m = re.search(r"file_id=(\w+)", out)
    ok = cl.returncode == 0 and m is not None
    print("backup finished OK:", ok)
    if not ok:
        return 1
    fid = m.group(1)

    out_file = os.path.join(BASE, "restored.bin")
    r = subprocess.run([PY, CLIENT, "restore", fid, out_file, "--servers", srv_spec],
                       capture_output=True, text=True)
    print(r.stdout.strip())
    match = sha(src) == sha(out_file)
    print("restored file identical to original:", match)

    print("== restarting h3, it should re-sync from h2")
    h3 = start_server("h3", 19003, 19002, "h2", a.delay, resync=True)
    total = count_chunks("h2")
    for _ in range(40):
        time.sleep(0.5)
        if count_chunks("h3") >= total:
            break
    print("chunks on h2: %d, on h3 after re-sync: %d" % (total, count_chunks("h3")))
    resynced = count_chunks("h3") >= total

    if not a.keep:
        for p in (h2, h3):
            p.kill()
    print("\nRESULT backup=%s restore=%s resync=%s" % (ok, match, resynced))
    return 0 if (ok and match and resynced) else 1


if __name__ == "__main__":
    sys.exit(main())
